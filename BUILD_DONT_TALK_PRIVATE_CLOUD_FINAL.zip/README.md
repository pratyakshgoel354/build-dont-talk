# BUILD DON'T TALK — Private Cloud Edition

A personal CBSE + JEE study dashboard. The deployed URL can be opened from any device, but personal records require your private password.

## Included
- Private password login (server-side verification; HttpOnly, Secure, SameSite cookie)
- Netlify Functions + Netlify Blobs cloud storage (no Firebase)
- Automatic cloud load/save for exams, CBSE/JEE chapter statuses, error notebook, daily tasks, revision logs and mock tests
- Exam countdowns, focus timer, analytics overview
- Responsive light minimalist sidebar layout

## Deploy step by step

### 1. Create a private GitHub repository
1. Download and extract this ZIP.
2. Open GitHub and create a **Private** repository, e.g. `build-dont-talk`.
3. Upload all extracted files and folders to the repository root. Do not upload the ZIP itself.

### 2. Deploy on Netlify
1. Sign in at https://app.netlify.com/
2. Select **Add new site → Import an existing project**.
3. Choose GitHub and select your private repository.
4. Build settings should be:
   - Build command: `npm run build`
   - Publish directory: `public`
5. Deploy the site.

### 3. Set your private login credentials
In Netlify:
1. Open your site → **Site configuration** (or **Project configuration**) → **Environment variables**.
2. Add `SITE_PASSWORD` = choose a long, unique password you do not use elsewhere.
3. Add `SESSION_SECRET` = a long random secret (at least 32 random characters). Generate one with a password manager.
4. Save variables and trigger **Deploys → Trigger deploy → Clear cache and deploy site**.

Do not share these values or put them in frontend files / GitHub.

### 4. Open on your devices
1. Open the Netlify URL on your laptop.
2. Enter your private password.
3. Open the same URL on your phone and enter the same password.
4. Changes are saved to Netlify Blobs and will load on your other device.

## Important notes
- Netlify Blobs is provisioned through the Netlify Functions runtime; no Firebase project or separate database setup is required.
- The app currently uses one private password for the owner (not individual user accounts). Anyone who knows that password can access the data, so keep it secret.
- The app does not include password reset. If you forget it, update `SITE_PASSWORD` in Netlify.
- This starter stores one JSON document for a single personal account. Avoid editing from multiple devices at the exact same moment; simultaneous whole-document saves can overwrite each other.
- Keep the GitHub repository private. The deployed URL itself is not a secret; access is gated by the login.
- This ZIP includes a starter chapter checklist. Verify the current official CBSE curriculum and JEE Main syllabus for latest inclusions/deletions.
- Review Netlify plan limits and pricing for Functions/Blobs before relying on it long term.
