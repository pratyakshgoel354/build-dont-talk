import { createHmac, timingSafeEqual } from 'node:crypto';
export function cookieValue(event) {
  const raw = event.headers.cookie || event.headers.Cookie || '';
  const item = raw.split(';').map(x=>x.trim()).find(x=>x.startsWith('bdt_session='));
  return item ? decodeURIComponent(item.slice('bdt_session='.length)) : '';
}
export function makeToken() {
  const payload = Buffer.from(String(Date.now())).toString('base64url');
  const sig = createHmac('sha256', process.env.SESSION_SECRET || '').update(payload).digest('base64url');
  return payload + '.' + sig;
}
export function validSession(event) {
  const token = cookieValue(event);
  const [payload, sig] = token.split('.');
  if (!payload || !sig || !process.env.SESSION_SECRET) return false;
  const expected = createHmac('sha256', process.env.SESSION_SECRET).update(payload).digest('base64url');
  const a=Buffer.from(sig), b=Buffer.from(expected);
  if (a.length!==b.length || !timingSafeEqual(a,b)) return false;
  const created=Number(Buffer.from(payload,'base64url').toString());
  return Number.isFinite(created) && Date.now()-created < 1000*60*60*24*30;
}
export const cookieOptions = 'Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000';
export function unauthorized(){return {statusCode:401,headers:{'Content-Type':'application/json'},body:JSON.stringify({error:'Please log in'})};}
