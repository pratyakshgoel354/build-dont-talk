import { timingSafeEqual } from 'node:crypto';
import { makeToken, cookieOptions } from './_auth.mjs';
export default async (req) => {
  if(req.method!=='POST') return {statusCode:405,body:'Method not allowed'};
  if(!process.env.SITE_PASSWORD || !process.env.SESSION_SECRET) return {statusCode:500,body:'Set SITE_PASSWORD and SESSION_SECRET in Netlify environment variables.'};
  let body={}; try{body=JSON.parse(req.body||'{}')}catch{}
  const supplied=Buffer.from(String(body.password||'')), actual=Buffer.from(process.env.SITE_PASSWORD);
  const ok=supplied.length===actual.length && timingSafeEqual(supplied,actual);
  if(!ok) return {statusCode:401,headers:{'Content-Type':'application/json'},body:JSON.stringify({error:'Incorrect password'})};
  return {statusCode:200,headers:{'Content-Type':'application/json','Set-Cookie':`bdt_session=${encodeURIComponent(makeToken())}; ${cookieOptions}`},body:JSON.stringify({ok:true})};
};
