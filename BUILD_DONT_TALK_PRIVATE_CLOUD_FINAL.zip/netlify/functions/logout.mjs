import { cookieOptions } from './_auth.mjs';
export default async () => ({statusCode:200,headers:{'Content-Type':'application/json','Set-Cookie':`bdt_session=; ${cookieOptions}; Max-Age=0`},body:JSON.stringify({ok:true})});
