import { getStore } from '@netlify/blobs';
import { validSession, unauthorized } from './_auth.mjs';
const headers={'Content-Type':'application/json','Cache-Control':'no-store'};
export default async (req) => {
  if(!validSession(req)) return unauthorized();
  const store=getStore('build-dont-talk-private');
  if(req.method==='GET'){
    const data=await store.get('personal-data.json',{type:'json'});
    return {statusCode:200,headers,body:JSON.stringify(data || {})};
  }
  if(req.method==='PUT'){
    let data={}; try{data=JSON.parse(req.body||'{}')}catch{return {statusCode:400,headers,body:JSON.stringify({error:'Invalid JSON'})};}
    const safe={exams:Array.isArray(data.exams)?data.exams:[], chapters:Array.isArray(data.chapters)?data.chapters:[], mistakes:Array.isArray(data.mistakes)?data.mistakes:[], tasks:Array.isArray(data.tasks)?data.tasks:[], tests:Array.isArray(data.tests)?data.tests:[], revisions:Array.isArray(data.revisions)?data.revisions:[], updatedAt:new Date().toISOString()};
    await store.setJSON('personal-data.json',safe);
    return {statusCode:200,headers,body:JSON.stringify({ok:true,updatedAt:safe.updatedAt})};
  }
  return {statusCode:405,headers,body:JSON.stringify({error:'Method not allowed'})};
};
